<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="1_Condo" tilewidth="32" tileheight="32" tilecount="714" columns="14">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/1_Condo.png" width="448" height="1632"/>
</tileset>
