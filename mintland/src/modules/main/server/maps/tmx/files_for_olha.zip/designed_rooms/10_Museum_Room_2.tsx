<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="10_Museum_Room_2" tilewidth="32" tileheight="32" tilecount="1584" columns="16">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/10_Museum_Room_2.png" width="512" height="3168"/>
</tileset>
