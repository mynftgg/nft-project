<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="7_TV" tilewidth="32" tileheight="32" tilecount="440" columns="11">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/7_TV.png" width="352" height="1280"/>
</tileset>
