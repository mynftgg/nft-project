<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="12_Museum_Room_4" tilewidth="32" tileheight="32" tilecount="480" columns="16">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/12_Museum_Room_4.png" width="512" height="960"/>
</tileset>
