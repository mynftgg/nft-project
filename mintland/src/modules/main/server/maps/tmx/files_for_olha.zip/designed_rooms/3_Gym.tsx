<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="3_Gym" tilewidth="32" tileheight="32" tilecount="1320" columns="20">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/3_Gym.png" width="640" height="2112"/>
</tileset>
