<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="11_Museum_Room_3" tilewidth="32" tileheight="32" tilecount="1197" columns="19">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/11_Museum_Room_3.png" width="608" height="2016"/>
</tileset>
