<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Room_Builder_32x32" tilewidth="32" tileheight="32" tilecount="8284" columns="76">
 <image source="../../../../client/maps/assets/Modern_Interiors/1_Interiors/32x32/Room_Builder_32x32.png" width="2432" height="3488"/>
 <tile id="12">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-1.77636e-15" y="0.364166" width="31.5611" height="31.6824"/>
  </objectgroup>
 </tile>
 <tile id="23">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0.121389" y="0.242777" width="31.3183" height="31.0755"/>
  </objectgroup>
 </tile>
 <tile id="34">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.00595356" y="0.235754" width="31.7981" height="31.8957"/>
  </objectgroup>
 </tile>
 <tile id="45">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.108412" y="0.216823" width="31.7646" height="31.6562"/>
  </objectgroup>
 </tile>
 <tile id="392">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.364166" y="0.242777" width="31.1969" height="31.9252"/>
  </objectgroup>
 </tile>
</tileset>
