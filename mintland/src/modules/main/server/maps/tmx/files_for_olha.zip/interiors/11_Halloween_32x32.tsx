<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="11_Halloween_32x32" tilewidth="32" tileheight="32" tilecount="976" columns="16">
 <image source="../../../../client/maps/assets/Modern_Interiors/1_Interiors/32x32/Theme_Sorter_32x32/11_Halloween_32x32.png" width="512" height="1952"/>
</tileset>
