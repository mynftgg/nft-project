<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="9_Museum_Room_1" tilewidth="32" tileheight="32" tilecount="1020" columns="20">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/9_Museum_Room_1.png" width="640" height="1632"/>
</tileset>
