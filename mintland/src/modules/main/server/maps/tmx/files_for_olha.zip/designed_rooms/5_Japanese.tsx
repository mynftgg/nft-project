<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="5_Japanese" tilewidth="32" tileheight="32" tilecount="820" columns="20">
 <image source="../../../../client/maps/assets/Modern_Interiors/Combined_Designs/5_Japanese.png" width="640" height="1312"/>
</tileset>
